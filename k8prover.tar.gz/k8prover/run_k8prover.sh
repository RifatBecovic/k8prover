#!/bin/bash

ACCOUNT=$1
WS_DIR="$(cd $(dirname $0) && pwd)"
LOG_DIR="$WS_DIR/prover.log"
APP_DIR="$WS_DIR/k8-prover"
APP_NAME="k8-prover"
APP_VER=`$WS_DIR/k8-prover -V`
CFG_POOL=pool.k8pool.com:4040
WORK_NAME=`hostname`


function GetINFO() {
    CPU_Model=`cat /proc/cpuinfo  | grep '^model name' | uniq | awk -F: '{ print \$2 }'`
    HOST_IPADDR=`hostname -I | xargs -n1 | head -n1`
    WORK_NAME=`hostname`
}

function UpHashesLog() {
    echo "INFO: pref Log ..."
    HasheSring=`tail -n 50 $LOG_DIR | sed -r "s/\x1B\[([0-9]{1,2}(;[0-9]{1,2})?)?[m|K]//g"  | grep -w "perf:" | tail -n 1`

    curl -s -X POST -H "'Content-type':'application/json'" \
    -d '{"account_name":"'"$ACCOUNT"'","worker_name":"'"$WORK_NAME"'","worker_ip":"'"$HOST_IPADDR"'","hashes":["'"$HasheSring"'"]}' \
    https://api.k8pool.com/api/v1/machine/add-log

    if [ $? -ne 0 ]; then
        echo "INFO: retry upHasheslog"
        sleep 3
        curl -s -X POST -H "'Content-type':'application/json'" \
        -d '{"account_name":"'"$ACCOUNT"'","worker_name":"'"$WORK_NAME"'","worker_ip":"'"$HOST_IPADDR"'","hashes":["'"$HasheSring"'"]}' \
        https://api.k8pool.com/api/v1/machine/add-log

    fi

}

#获取基本信息
GetINFO

#上报机器信息
curl -s -X POST -H "'Content-type':'application/json'" \
     -d '{"account_name":"'"$ACCOUNT"'","worker_name":"'"$WORK_NAME"'","worker_ip":"'"$HOST_IPADDR"'","cpu_type":"'"$CPU_Model"'","version":"'"$APP_VER"'"}' \
     https://api.k8pool.com/api/v1/machine/save

#重试上报机器信息
if [ $? -ne 0 ]; then
  echo "INFO: retry register machine"
  sleep 3
  curl -s -X POST -H "'Content-type':'application/json'" \
     -d '{"account_name":"'"$ACCOUNT"'","worker_name":"'"$WORK_NAME"'","worker_ip":"'"$HOST_IPADDR"'","cpu_type":"'"$CPU_Model"'","version":"'"$APP_VER"'"}' \
     https://api.k8pool.com/api/v1/machine/save

fi

echo "INFO: start k8prover guard ......"
##start k8prover
while true; do

    NUM=`ps aux | grep ${APP_NAME} | grep ":4040" |grep -v grep | wc -l`
    if [ "${NUM}" -lt "1" ];then
        echo "INFO: 进程启动，进程pid: $!"
	echo "nohup $APP_DIR -c $ACCOUNT -d $WORK_NAME -g 0 -p $CFG_POOL >> $LOG_DIR 2>&1 &"
	nohup $APP_DIR -c $ACCOUNT -d $WORK_NAME -g 0 -p $CFG_POOL >> $LOG_DIR 2>&1 &
    else
        echo "INFO: $APP_DIR run OK."
    fi

    sleep 120

    #上报心跳
    UpHashesLog

done
